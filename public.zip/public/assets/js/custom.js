"use strict";

const navbar = document.querySelector(".navbar");
const breakpoint = navbar.getBoundingClientRect().bottom;

window.addEventListener("scroll", function () {
  if (this.scrollY > breakpoint) {
    navbar.classList.add("sticky");
  } else {
    navbar.classList.remove("sticky");
  }
});
